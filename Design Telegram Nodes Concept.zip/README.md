
  # Design Telegram Nodes Concept

  This is a code bundle for Design Telegram Nodes Concept. The original project is available at https://www.figma.com/design/ZaPJDQ99gRdmhV4vqlRpBI/Design-Telegram-Nodes-Concept.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  